#!/usr/bin/env python3
"""
Attempt Accounting Report — machine-produced, classification-rules-based.

Two tiers of authority:

  Tier 1 (AUTHORITATIVE): If the FL body contains a LINEAGE_JSON block with an
  `attempt_counter` object, that object's breakdown (runtime_fixes, tooling_only,
  observation_only, documentation_only, total) is the source of truth for the
  numbered attempt table. The classifier does NOT re-derive those numbers.

  Tier 2 (CLASSIFIER-DERIVED): For FL entries that have no LINEAGE_JSON tombstone,
  or for the post-tombstone accounting headers in entries that do have one, the
  classifier applies keyword rules to each block's **Approach:** prefix.
  The resulting counts are true relative to those rules, not facts derivable from
  log headers alone.

Header counts (total #### Fix attempt headers per FL) are structurally derivable
from docs/FAILURE_LOG.md without body parsing.
"""

import re
import subprocess
import sys
from dataclasses import dataclass
from typing import Optional

# ---------------------------------------------------------------------------
# Classification rules (ordered: first match wins)
# Rule: (keyword_pattern, class_id, description)
# ---------------------------------------------------------------------------
RULES = [
    # ── Disqualified / process error ────────────────────────────────────────
    (r"MISTAKEN LAUNCH PATH",          "disqualified",  "Process error — launch invalid; results void"),
    (r"PROCESS FAILURE",               "disqualified",  "Process-level failure (preflight/deploy blocked)"),
    (r"PRELAUNCH BLOCKER",             "disqualified",  "Run never reached gameplay; no evidence"),
    # ── Actual runtime/gameplay behavior changes ─────────────────────────────
    (r"RUNTIME FIX ATTEMPT",           "candidate_fix", "Intended runtime fix — behavior change attempted"),
    (r"RUNTIME FIX",                   "candidate_fix", "Confirmed runtime fix commit"),
    (r"VISUAL REGRESSION FIX ATTEMPT", "candidate_fix", "Client render regression fix attempt"),
    (r"POST-CACHE SWEEP PRUNE",        "candidate_fix", "Sweep-prune optimization after cache hit"),
    (r"BATCH \d+.*fix",                "candidate_fix", "Batch of non-conflicting runtime fixes"),
    (r"BEHAVIOR PATCH",                "candidate_fix", "Runtime behavior change patch"),
    (r"FL-\d+ fix-attempt:",           "candidate_fix", "Inlined fix-attempt (FL-ref prefix form)"),
    (r"IMPLEMENTED\s+partial",         "candidate_fix", "Partial implementation commit"),
    (r"IMPLEMENTED",                   "candidate_fix", "Implementation commit"),
    # ── Tooling / instrumentation ────────────────────────────────────────────
    (r"TOOLING FIX",                   "tooling",       "Fix to watchdog/analyzer tooling, not game code"),
    (r"TOOLING",                       "tooling",       "Watchdog/analyzer tooling work"),
    (r"INSTRUMENTATION",               "tooling",       "Observability/telemetry additions only"),
    (r"H\d+ FALLBACK TOOLING",         "tooling",       "Hypothesis-gated tooling addition"),
    (r"H-LANE TOOLING",                "tooling",       "Hypothesis-lane tooling"),
    (r"RESEARCH VERIFY.*TOOLING",      "tooling",       "Research + tooling (no gameplay change)"),
    (r"TRACE TABLE",                   "tooling",       "Trace table / watchdog metric tooling"),
    (r"OVERLAY \+",                    "tooling",       "Inline overlay + source comment tooling"),
    (r"PROCESS FIX ATTEMPT",           "tooling",       "Fix to run process/canonical wrapper, not gameplay"),
    # ── Observations / run receipts ──────────────────────────────────────────
    (r"FALSIFICATION RUN",             "observation",   "Planned falsification run"),
    (r"RECEIPT \+ TOOLING GAP",        "observation",   "Run receipt + tooling gap (no fix)"),
    (r"RECEIPT \+ PIVOT",              "observation",   "Run receipt with direction pivot"),
    (r"RECEIPT CORRECTED",             "observation",   "Corrected run receipt"),
    (r"RECEIPT",                       "observation",   "Run result receipt"),
    (r"OBSERVATION",                   "observation",   "Direct observation"),
    (r"PROOF RUN FAIL",                "observation",   "Proof run that failed — observation only"),
    (r"PROOF PASS",                    "observation",   "Proof run that passed — evidence"),
    (r"PROOF RESULT",                  "observation",   "Proof run result"),
    (r"PARTIAL PROOF",                 "observation",   "Partial proof run result"),
    (r"FAILED PROOF UPDATE",           "observation",   "Failed proof run update"),
    (r"BAD-LAG RERUN EVIDENCE",        "observation",   "Run showing lag still present"),
    (r"LIVE REPLAY ANALYSIS",          "observation",   "Live replay observation"),
    (r"PARTIAL TRACE RECEIPT",         "observation",   "Trace table receipt"),
    (r"HEADED RECEIPT",                "observation",   "Run receipt after fix — observation"),
    (r"REJECTED/REVERTED",             "observation",   "Reverted — no net change"),
    # ── Analysis / diagnosis ─────────────────────────────────────────────────
    (r"DIAGNOSIS SUMMARY",             "analysis",      "Multi-run diagnosis summary"),
    (r"DIAGNOSIS",                     "analysis",      "Diagnosis entry"),
    (r"FOLLOW-UP",                     "analysis",      "Follow-up analysis"),
    (r"LAG OWNER CORRECTION",          "analysis",      "Correcting the named lag owner"),
    (r"HEADED AUTHORITY.*SOURCE OWNER","analysis",      "Source-read authority clarification"),
    (r"SOURCE TRACE OVERLAYS",         "analysis",      "Source annotation overlays"),
    (r"SOURCE-FIRST ANALYSIS",         "analysis",      "Source-first analysis pass"),
    (r"INVESTIGATION",                 "analysis",      "Investigation / audit block"),
    (r"CLASSIFICATION",                "analysis",      "Run classification audit"),
    (r"RESEARCH VERIFY",               "analysis",      "Source-verification pass"),
    (r"HYPOTHESIS LEDGER",             "analysis",      "Multi-hypothesis inventory"),
    (r"HYPOTHESIS",                    "analysis",      "Hypothesis entry"),
    (r"AUDIT BACKFILL",                "analysis",      "Hypothesis/attempt backfill audit"),
    (r"BACKFILL",                      "analysis",      "Lineage / attempt backfill"),
    (r"CORRECTION",                    "analysis",      "Correction of prior claim"),
    (r"IO-POLL-GAP FINDING",           "analysis",      "IO poll gap investigation finding"),
    (r"HISTORICAL LAG BROWSE",         "analysis",      "Historical artifact browse"),
    (r"CRITICAL FINDING",              "analysis",      "Critical cross-run finding"),
    (r"FALSIFICATION",                 "analysis",      "Explicit falsification of a hypothesis"),
    (r"VALIDATION OF PASTED",          "analysis",      "Source validation of pasted diagnosis"),
    (r"SECONDARY OVERHEAD",            "analysis",      "Secondary overhead seam analysis"),
    (r"PROCESS CORRECTION",            "analysis",      "Process-level correction note"),
    (r"A/B hot-position",              "analysis",      "A/B comparison harness run"),
    (r"Controlled current-HEAD",       "analysis",      "Controlled diagnostic toggle run"),
    (r"Stateful hot-region",           "analysis",      "Stateful hot-region harness"),
    (r"GATE-TRUTH PATCH",              "analysis",      "Gate truth / semantics correction"),
    (r"ARCHIVE RECOMPUTE",             "analysis",      "Archive lag-gate recompute"),
    (r"TRACE-TRUTH PATCH",             "analysis",      "Trace attribution correction"),
    (r"LAST-\d+-DAYS LAG AUDIT",       "analysis",      "Lag band audit over recent runs"),
    (r"FULL ARTIFACT TABLE",           "analysis",      "Full artifact table recompute"),
    (r"EVIDENCE UPDATE",               "analysis",      "Evidence-based update / correction"),
    # Attempt #N: — look at sub-keywords to sub-classify
    (r"Attempt #\d+.*(?:runtime fix|fix attempt|optimization|prune|patch)",
                                       "candidate_fix", "Numbered attempt — runtime/behavior fix"),
    (r"Attempt #\d+.*(?:tooling|instrumentation|seam|instr)",
                                       "tooling",       "Numbered attempt — tooling/instrumentation"),
    (r"Attempt #\d+.*(?:proof|receipt|result|rerun|run-)",
                                       "observation",   "Numbered attempt — run observation"),
    (r"Attempt #\d+.*(?:analysis|validate|source|owner|correct|audit)",
                                       "analysis",      "Numbered attempt — analysis/source read"),
    (r"ATTEMPT #\d+.*(?:fix|bound|patch|change)",
                                       "candidate_fix", "Numbered ATTEMPT — runtime/behavior fix"),
    (r"ATTEMPT #\d+.*(?:watchdog|script|tooling|instr|flags)",
                                       "tooling",       "Numbered ATTEMPT — tooling"),
    (r"Attempt #\d+",                  "analysis",      "Numbered attempt (unclassified sub-type)"),
    (r"ATTEMPT #\d+",                  "analysis",      "Numbered ATTEMPT (unclassified sub-type)"),
    # ── Pre-run planning ─────────────────────────────────────────────────────
    (r"INTENT",                        "intent",        "Pre-run intent declaration — no run yet"),
    # ── Meta-analysis ────────────────────────────────────────────────────────
    (r"Compound-engineering",          "meta_analysis", "Compound-engineering multi-attempt audit"),
    # ── Miscellaneous catch-alls (must be late in list) ──────────────────────
    (r"post-launch audit",             "analysis",      "Post-launch process audit"),
    (r"Phase-0 lag attribution",       "tooling",       "Phase-0 lag attribution seam work"),
    (r"Share the FL-\d+",              "tooling",       "Sharing/propagating instrumentation"),
    (r"Carry the",                     "analysis",      "Analysis continuation"),
    (r"Logged the proof-boundary",     "analysis",      "Proof boundary logging"),
    (r"Instrumented the client",       "tooling",       "Client instrumentation"),
    (r"Stable mesh identity",          "tooling",       "Stable mesh identity instrumentation"),
    (r"Pathological work-item forensic","tooling",      "Forensic instrumentation"),
    (r"FL-\d+ repeat exact",           "observation",   "Repeat-exact run series"),
    (r"FL-\d+ diagnostic",             "observation",   "Diagnostic run"),
    (r"FL-\d+ combined",               "observation",   "Combined proof run"),
    (r"Support-retry collector",       "tooling",       "Support-retry collector instrumentation"),
    (r"RESULT:",                       "observation",   "Run result block"),
    (r"RUN ANALYSIS",                  "observation",   "Run analysis block"),
    (r"NOTE \(",                       "analysis",      "Note / linkage annotation"),
    # Remaining unknown patterns identified from first pass
    (r"Verified FL-\d+",               "analysis",      "Source verification against live checkout"),
    (r"FL-\d+ lag proof:",             "observation",   "Lag proof test observation"),
    (r"CORRECTED:",                    "analysis",      "Correction of prior claim"),
    (r"Secondary overhead patch",      "candidate_fix", "Secondary overhead seam fix"),
    (r"Process correction for secondary-overhead",
                                       "analysis",      "Process/linkage correction"),
    (r"Falsifiability repair",         "analysis",      "Falsifiability definition repair"),
    (r"Trace table passive",           "observation",   "Trace table passive run observation"),
    (r"Correct problem:",              "analysis",      "Problem framing correction"),
    (r"FL-\d+ / Lag-family.*Commit:",  "candidate_fix", "Lag-family update with commit"),
    (r"Target the two exact",          "candidate_fix", "Targeted physics edge fix"),
    (r"^\[\d{8}-\d{6} run-\d\]",      "observation",   "Run-N format observation block"),
    (r"FL-\d+ fix-attempt #\d+: commit",
                                       "candidate_fix", "Inlined fix-attempt with commit hash"),
    (r"Corrected the freeze wording",  "analysis",      "Correction of prior freeze claim"),
    (r"Added instrumentation only",    "tooling",       "Instrumentation-only addition"),
    (r"FL-\d+ same-recipe",            "observation",   "Same-recipe rerun observation"),
    (r"TRACE_TABLE_CONFIRMATION",      "observation",   "Trace table confirmation run"),
]

CLASS_DISPLAY = {
    "candidate_fix":  "CANDIDATE FIX",
    "tooling":        "TOOLING/INSTRUMENTATION",
    "observation":    "OBSERVATION/RECEIPT",
    "analysis":       "ANALYSIS/DIAGNOSIS",
    "intent":         "INTENT/PLANNING",
    "meta_analysis":  "META-ANALYSIS",
    "disqualified":   "DISQUALIFIED (process error)",
    "unknown":        "UNKNOWN/UNCATEGORIZED",
}


@dataclass
class AttemptBlock:
    number: int
    date: str
    branch: str
    approach_raw: str
    class_id: str
    rule_description: str
    keyword_matched: str


def classify(approach: str) -> tuple[str, str, str]:
    """Return (class_id, rule_description, keyword_matched)."""
    for pattern, class_id, description in RULES:
        m = re.search(pattern, approach)
        if m:
            return class_id, description, m.group(0)
    return "unknown", "No rule matched", ""


def parse_prior_attempts(text: str) -> list[AttemptBlock]:
    """Parse the output of `fl prior-attempts FL-NNN`."""
    blocks = []
    # Split on block headers: [N] DATE  @  BRANCH
    block_re = re.compile(r"^\[(\d+)\]\s+(\d{4}-\d{2}-\d{2})\s+@\s+(\S+)", re.MULTILINE)
    approach_re = re.compile(r"\*\*Approach:\*\*\s+(.+)", re.DOTALL)

    matches = list(block_re.finditer(text))
    for i, m in enumerate(matches):
        num = int(m.group(1))
        date = m.group(2)
        branch = m.group(3)
        # Extract the text for this block
        start = m.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        body = text[start:end]

        am = approach_re.search(body)
        approach_raw = am.group(1).strip()[:300] if am else ""
        class_id, rule_desc, kw = classify(approach_raw)
        blocks.append(AttemptBlock(num, date, branch, approach_raw, class_id, rule_desc, kw))

    return blocks


def run_prior_attempts(fl_id: str) -> str:
    result = subprocess.run(
        ["python3", "scripts/analyze_runs.py", "fl", "prior-attempts", fl_id],
        capture_output=True, text=True
    )
    return result.stdout


_LINEAGE_JSON_RE = re.compile(
    r'\{"lineage_tag":"LINEAGE_JSON"[^}]*"attempt_counter":\s*(\{[^}]+\})',
    re.DOTALL,
)


def extract_lineage_attempt_counter(raw_show_output: str) -> Optional[dict]:
    """
    Return the attempt_counter dict from a LINEAGE_JSON block in the FL body,
    or None if absent.  This is the authoritative breakdown for the numbered
    attempt table — do not re-derive these numbers from headers.
    """
    m = _LINEAGE_JSON_RE.search(raw_show_output)
    if not m:
        return None
    try:
        import json as _json
        return _json.loads(m.group(1))
    except Exception:
        return None


def run_show(fl_id: str) -> str:
    result = subprocess.run(
        ["python3", "scripts/analyze_runs.py", "fl", "show", fl_id],
        capture_output=True, text=True
    )
    return result.stdout


def report_one(fl_id: str, prior_text: str, show_text: str = "") -> dict:
    blocks = parse_prior_attempts(prior_text)
    total_headers = len(blocks)

    # Tier 1: check for authoritative LINEAGE_JSON tombstone
    lineage_counter = extract_lineage_attempt_counter(show_text) if show_text else None

    if lineage_counter:
        # Tombstone present — it covers the numbered attempt table.
        # The remaining headers (total_headers - lineage_counter["total"]) are
        # post-tombstone accounting overhead (receipts, overlays, analysis).
        authoritative_total = lineage_counter.get("total", 0)
        accounting_overhead = total_headers - authoritative_total
        return {
            "fl": fl_id,
            "total_headers": total_headers,
            "source": "lineage_json_tombstone",
            "authoritative": lineage_counter,
            "accounting_overhead_headers": max(0, accounting_overhead),
            "blocks": blocks,
            "by_class": {},  # not classifier-derived when tombstone present
        }

    # Tier 2: no tombstone — classify all blocks by keyword rules
    by_class: dict[str, list[AttemptBlock]] = {}
    for b in blocks:
        by_class.setdefault(b.class_id, []).append(b)

    return {
        "fl": fl_id,
        "total_headers": total_headers,
        "source": "classifier",
        "authoritative": None,
        "accounting_overhead_headers": 0,
        "blocks": blocks,
        "by_class": by_class,
    }


def print_report(reports: list[dict]) -> None:
    total_headers_all = sum(r["total_headers"] for r in reports)
    print("=" * 78)
    print("ATTEMPT ACCOUNTING REPORT")
    print(f"Generated: 2026-05-08  |  Source: analyze_runs.py fl prior-attempts + fl show")
    print(f"Total #### Fix attempt headers across all listed FL entries: {total_headers_all}")
    print()
    print("AUTHORITY TIERS")
    print("-" * 78)
    print("  Tier 1 (LINEAGE_JSON tombstone): when present in the FL body, the embedded")
    print("  attempt_counter is the authoritative breakdown for the numbered attempt table.")
    print("  Classifier rules are NOT applied to the tombstoned portion.")
    print()
    print("  Tier 2 (classifier-derived): for entries without a tombstone, and for the")
    print("  post-tombstone accounting headers in entries that do have one, keyword rules")
    print("  are applied to the **Approach:** prefix. Results are true relative to those")
    print("  rules, not facts derivable from log headers alone.")
    print()

    all_classes = ["candidate_fix", "tooling", "observation", "analysis",
                   "intent", "meta_analysis", "disqualified", "unknown"]
    abbr = {
        "candidate_fix": "FIX", "tooling": "TOOL", "observation": "OBS",
        "analysis": "ANAL", "intent": "INTNT", "meta_analysis": "META",
        "disqualified": "DISQ", "unknown": "UNK",
    }

    # Per-FL breakdown
    for r in reports:
        fl = r["fl"]
        total_h = r["total_headers"]
        source = r["source"]

        print("=" * 78)
        if source == "lineage_json_tombstone":
            ac = r["authoritative"]
            overhead = r["accounting_overhead_headers"]
            print(f"  {fl}  —  {total_h} headers  [TIER 1: LINEAGE_JSON tombstone]")
            print("-" * 78)
            print(f"  Authoritative attempt_counter (numbered table, attempts 1–{ac.get('total',0)}):")
            print(f"    total={ac.get('total',0)}  runtime_fixes={ac.get('runtime_fixes',0)}"
                  f"  tooling_only={ac.get('tooling_only',0)}"
                  f"  observation_only={ac.get('observation_only',0)}"
                  f"  documentation_only={ac.get('documentation_only',0)}")
            if overhead > 0:
                print(f"  Post-tombstone accounting headers (not counted as attempts): {overhead}")
                print(f"  (receipts, overlays, analysis blocks logged after the numbered table closed)")
        else:
            by_class = r["by_class"]
            print(f"  {fl}  —  {total_h} headers  [TIER 2: classifier-derived]")
            print("-" * 78)
            if total_h == 0:
                print("  (no prior-attempts output)")
            else:
                for class_id in all_classes:
                    items = by_class.get(class_id, [])
                    if not items:
                        continue
                    display = CLASS_DISPLAY[class_id]
                    print(f"  {display} ({len(items)})")
                    for b in items:
                        kw = f"[{b.keyword_matched}] " if b.keyword_matched else ""
                        snippet = b.approach_raw[:80].replace("\n", " ")
                        print(f"    [{b.number}] {b.date}  {kw}{snippet}…")
        print()

    # Cross-entry summary table
    print("=" * 78)
    print("CROSS-ENTRY SUMMARY (Window 1: May 3–8, 2026)")
    print("-" * 78)
    print(f"  {'FL':<12} {'HDRS':>5}  {'AUTH':>5}  {'OVERHEAD':>8}  "
          f"{'FIX':>4}  {'TOOL':>4}  {'OBS':>4}  {'ANAL':>4}  {'UNK':>4}  SOURCE")
    print(f"  {'-'*12} {'-'*5}  {'-'*5}  {'-'*8}  "
          f"{'-'*4}  {'-'*4}  {'-'*4}  {'-'*4}  {'-'*4}  ------")

    grand_headers = 0
    grand_auth = 0
    grand_overhead = 0
    grand_fix = 0

    for r in reports:
        fl = r["fl"]
        hdrs = r["total_headers"]
        grand_headers += hdrs

        if r["source"] == "lineage_json_tombstone":
            ac = r["authoritative"]
            auth_total = ac.get("total", 0)
            overhead = r["accounting_overhead_headers"]
            rfx = ac.get("runtime_fixes", 0)
            tool = ac.get("tooling_only", 0)
            obs = ac.get("observation_only", 0)
            doc = ac.get("documentation_only", 0)
            anal = doc  # documentation_only ≈ analysis in tombstone vocabulary
            unk = auth_total - rfx - tool - obs - doc
            grand_auth += auth_total
            grand_overhead += overhead
            grand_fix += rfx
            print(f"  {fl:<12} {hdrs:>5}  {auth_total:>5}  {overhead:>8}  "
                  f"{rfx:>4}  {tool:>4}  {obs:>4}  {anal:>4}  {unk:>4}  tombstone")
        else:
            by_class = r["by_class"]
            fix_n = len(by_class.get("candidate_fix", []))
            tool_n = len(by_class.get("tooling", []))
            obs_n = len(by_class.get("observation", []))
            anal_n = len(by_class.get("analysis", []))
            unk_n = len(by_class.get("unknown", []))
            grand_fix += fix_n
            print(f"  {fl:<12} {hdrs:>5}  {'—':>5}  {'—':>8}  "
                  f"{fix_n:>4}  {tool_n:>4}  {obs_n:>4}  {anal_n:>4}  {unk_n:>4}  classifier")

    print(f"  {'':=<12} {'=':=>5}  {'=':=>5}  {'=':=>8}  "
          f"{'=':=>4}  {'=':=>4}  {'=':=>4}  {'=':=>4}  {'=':=>4}")
    print(f"  {'TOTAL':<12} {grand_headers:>5}  {grand_auth:>5}  {grand_overhead:>8}  "
          f"(mix of tombstone and classifier sources — see per-row SOURCE column)")

    print()
    print("COLUMNS: HDRS=total #### Fix attempt headers | AUTH=tombstone attempt_counter.total")
    print("         OVERHEAD=post-tombstone accounting headers (not counted as fix attempts)")
    print("         FIX=runtime_fixes (tombstone) or candidate_fix (classifier)")
    print("         TOOL/OBS/ANAL/UNK: tombstone fields or classifier classes")
    print()
    print("WHAT IS DERIVABLE FROM HEADERS ALONE (no body parsing)")
    print("-" * 78)
    print(f"  Total #### Fix attempt headers across listed FLs: {grand_headers}")
    print(f"  FL-2957 alone: 120 (May 4–8, 2026)")
    print()
    print("WHAT REQUIRES BODY PARSING OR LINEAGE_JSON")
    print("-" * 78)
    print("  Whether each header is a gameplay fix, tooling, receipt, or analysis.")
    print("  FL-2957 authoritative: LINEAGE_JSON total=23 (runtime_fixes=5, tooling=7,")
    print("    observation=9, documentation=2) — covers numbered attempts 1–23.")
    print("  Remaining 97 FL-2957 headers: post-tombstone accounting (not fix attempts).")
    print()
    print("  For FL entries without a LINEAGE_JSON tombstone, all classification is")
    print("  classifier-derived and should be labeled as such, not as log facts.")


def main():
    # FL entries to analyze (Window 1: May 3-8, 2026)
    fl_ids = [
        "FL-2957",
        "FL-3688", "FL-2875",
        "FL-2975", "FL-2976", "FL-2977",
        "FL-2952", "FL-2953", "FL-2954",
        "FL-2978", "FL-2979", "FL-2980", "FL-2981",
        "FL-3208",
        "FL-3630", "FL-3631",
        "FL-3715", "FL-3716", "FL-3717", "FL-3718",
        "FL-3706", "FL-3160",
    ]

    reports = []
    for fl_id in fl_ids:
        if fl_id == "FL-2957":
            try:
                with open("/tmp/fl2957_prior.txt") as f:
                    prior_text = f.read()
            except FileNotFoundError:
                prior_text = run_prior_attempts(fl_id)
        else:
            prior_text = run_prior_attempts(fl_id)
        # Always fetch the show output for tombstone extraction
        show_text = run_show(fl_id)
        reports.append(report_one(fl_id, prior_text, show_text))

    print_report(reports)


if __name__ == "__main__":
    main()
